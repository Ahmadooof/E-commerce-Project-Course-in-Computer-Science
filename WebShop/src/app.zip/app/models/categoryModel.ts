export interface categoryModel {
    key: string;
    title: string; 
}